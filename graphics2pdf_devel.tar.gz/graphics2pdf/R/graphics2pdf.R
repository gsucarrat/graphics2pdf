graphics2pdf <- function(file.names=NULL, stem.name="graphics",
  scale=0.17, angle=-90, quality=30, page.style="empty", create.pdf=TRUE,
  open.pdf=TRUE, clean=TRUE)
{

  if(is.null(file.names)){ file.names <- tk_choose.files() }
  if(is.null(file.names)){ stop("No files chosen") }
  if(length(file.names)==0){ stop("No files chosen") }

  ##identify target directory:
  ##==========================

#for the future?:
#  sysinfo <- Sys.info()
#  slash <- ifelse(sysinfo["sysname"]=="Windows", "/", "\\")
  nChar <- nchar(file.names[1])
  for(i in nChar:1){
    if( substr(file.names[1], i, i)=="/" ){
      target.dir <- substr(file.names[1], 1, i)
      iStart <- i+1
      break
    }
  }
  
  ##modify file.names:
  ##==================
  
  for(i in 1:length(file.names)){
    file.names[i] <- substr(file.names[i], iStart, nchar(file.names[i]))
  }
  
  ##reduce file size:
  ##=================
  
  cat("\n Creating auxiliary files...\n")
  NEWfile.names <- paste0(target.dir, "NEW", file.names)
  for(i in 1:length(file.names)){
    tmp <- image_read(paste0(target.dir, file.names[i]))
    image_write(tmp, path=NEWfile.names[i], quality=quality)
  }
    
  ##modify scale and angle
  ##======================
  
  if(length(scale)==1){ scale <- rep(scale, length(file.names)) }
  if(length(angle)==1){ angle <- rep(angle, length(file.names)) }
  
  ##open connection
  ##===============
  
  tex.name <- paste0(stem.name, ".tex")
  filePath <- paste0(target.dir, tex.name)
  sink(filePath)
  
  
  ##make preamble
  ##=============
  
  cat("\\documentclass[12pt,a4]{article} \n")
  cat("\\usepackage{graphicx} \n") #needed for the [scale..] argument
  
  ##set margins:
  cat("\n") #add some space
  cat("\\addtolength{\\textheight}{8cm} \n") #change textheight
  cat("\\addtolength{\\voffset}{-4cm} \n") #- moves up, + moves down
  cat("\\addtolength{\\textwidth}{6cm} \n") #change textwidth
  cat("\\addtolength{\\hoffset}{-3cm} \n") #- moves left, + moves right
  
  ##pagestyle:
  if(!is.null(page.style)){
    cat("\n", "\\pagestyle{", page.style, "} \n", sep="")
  }
  
  ##document body
  ##=============
  
  ##begin document environment:
  cat("\n", "\\begin{document} \n", sep="")
  
  ##create the pages:
  for(i in 1:length(NEWfile.names)){
  
    cat("\n")
    if(i > 1){ cat("\\newpage \n") }
    cat("\\begin{center} \n")
    cat("\\includegraphics[scale=", scale[i], ", angle=", angle[i], "]{",
      NEWfile.names[i], "} \n",
      sep="")
    cat("\\end{center} \n")
  
  }
  
  ##end document environment:
  cat("\n", "\\end{document} \n", sep="")
  
  
  ##close connection
  ##================
  
  sink()
  
  
  ##build pdf
  ##=========
  
  ##create pdf:
  if( create.pdf ){
    cat(" Creating PDF... \n")
    tmpWD <- getwd()
    setwd( target.dir )
    texi2pdf(tex.name, clean = clean)
    setwd(tmpWD)
    if( !clean ){
      cat(" Use 'scale' and 'angle' in .tex file to change scale and rotation \n")
    }
  }

  ##for the future: use compactPDF for compression? Probably not,
  ##it may be difficult to get it working
  
  ##clean auxiliary graphic files:
  ##==============================
  
  if( clean ){
    cat(" Deleting auxiliary files... (set 'clean = TRUE' to keep them) \n")
    ##delete .tex file:
    file.remove( paste0(target.dir, tex.name) )
    ##delete graphics files:
    for(i in 1:length(NEWfile.names)){
      file.remove(NEWfile.names[i])
    }
  }
  
  ##open pdf
  ##========

  if( open.pdf && create.pdf ){
    cat(" Opening PDF... \n")
    filePath <- paste0(target.dir, stem.name, ".pdf")
    tmp <- system( paste0('open "', filePath, '"') )
#OLD (does not seem to work with spaces in 'args'):
#    system2("open", args=filePath)
  }

  ##add a linespace at the end:
  ##===========================
  
  cat("\n")
  
} #close graphics2pdf()
