graphics2pdf <-
function(file.names=NULL, stem.name="graphics",
  scale=0.16, angle=-90, page.style="empty", create.pdf=TRUE,
  open.pdf=TRUE, clean=FALSE)
{

  if(is.null(file.names)){ file.names <- tk_choose.files() }
  if(is.null(file.names)){ stop("No files chosen") }
  
  ##identify the target directory
  ##=============================
  
  nChar <- nchar(file.names[1])
  for(i in nChar:1){
    if( substr(file.names[1], i, i)=="/" ){
      target.dir <- substr(file.names[1], 1, i)
      iStart <- i+1
      break
    }
  }
  
  ##modify file.names
  ##=================
  
  for(i in 1:length(file.names)){
    file.names[i] <- substr(file.names[i], iStart, nchar(file.names[i]))
  }
  
  
  ##modify scale and angle
  ##======================
  
  if(length(scale)==1){ scale <- rep(scale, length(file.names)) }
  if(length(angle)==1){ angle <- rep(angle, length(file.names)) }
  
  ##open connection
  ##===============
  
  tex.name <- paste0(stem.name, ".tex")
  filePath <- paste0(target.dir, tex.name)
  sink(filePath)
  
  
  ##make preamble
  ##=============
  
  cat("\\documentclass[12pt,a4]{article} \n")
  cat("\\usepackage{graphicx} \n") #needed for the [scale..] argument
  
  ##set margins:
  cat("\n") #add some space
  cat("\\addtolength{\\textheight}{8cm} \n") #change textheight
  cat("\\addtolength{\\voffset}{-4cm} \n") #- moves up, + moves down
  cat("\\addtolength{\\textwidth}{6cm} \n") #change textwidth
  cat("\\addtolength{\\hoffset}{-3cm} \n") #- moves left, + moves right
  
  ##pagestyle:
  if(!is.null(page.style)){
    cat("\n", "\\pagestyle{", page.style, "} \n", sep="")
  }
  
  ##document body
  ##=============
  
  ##begin document environment:
  cat("\n", "\\begin{document} \n", sep="")
  
  ##create the pages:
  for(i in 1:length(file.names)){
  
    cat("\n")
    if(i > 1){ cat("\\newpage \n") }
    cat("\\begin{center} \n")
    cat("\\includegraphics[scale=", scale[i], ", angle=", angle[i], "]{",
      file.names[i], "} \n",
      sep="")
    cat("\\end{center} \n")
  
  }
  
  ##end document environment:
  cat("\n", "\\end{document} \n", sep="")
  
  
  ##close connection
  ##================
  
  sink()
  
  
  ##build and open pdf
  ##==================
  
  ##create pdf:
  if(create.pdf){
    cat("\n Creating PDF... \n")
    tmpWD <- getwd()
    setwd( target.dir )
    texi2pdf(tex.name, clean = clean)
    setwd(tmpWD)
    cat(" Use 'scale' and 'angle' to change scale and rotation \n",
      sep="")
  }
  
  ##open pdf:
  if(open.pdf && create.pdf){
    filePath <- paste0(target.dir, stem.name, ".pdf")
    system2("open", args=filePath)
#OLD:
#    nChar <- nchar(filePath)
#    filePathPDF <- paste0(substr(filePath, 1, nChar-3), "pdf")
#    system2("open", args=filePathPDF)
  }

}
