##make shortcut alias for graphics2pdf():
g2p <- function(...){ graphics2pdf(...) }